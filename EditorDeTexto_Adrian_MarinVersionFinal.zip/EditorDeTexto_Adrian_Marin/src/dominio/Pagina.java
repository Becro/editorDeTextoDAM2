/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyledEditorKit;

/**
 *
 * @author amfro
 */
public class Pagina extends JTextPane implements KeyListener, MouseListener {
	private Lamina lamina;
	private JPopupMenu menu;

	// Declaracion de booleanos para seleccionar los menus
	private boolean presNegrita, presSubrayado, presCursiva;

	public Pagina(Lamina lamina) {
		this.lamina = lamina;
		this.menu = new JPopupMenu();
		// Establecemos el tamaño, que será unos pixeles más pequeño que la Lamina
		setSize(new Dimension(lamina.getHeight() - 10, lamina.getWidth() - 10));

		this.presNegrita = false;
		this.presSubrayado = false;
		this.presCursiva = false;
		System.out.println("Valor negrita= " + presNegrita);
		JPopupMenu menu= crearMenu();
		this.setComponentPopupMenu(menu);
		setVisible(true);

		addKeyListener(this);
		addMouseListener(this);

	}

	// Este m�todo se encarga de tomar los valores iniciales
	public void iniciar(String nombreFuente, int tamanyo) {

		this.setFont(new Font(nombreFuente, Font.PLAIN, tamanyo));

	}

	public void cambiarTamanyoTexto(ActionEvent e, int tamanyo) {
		System.out.println("tama�o = " + tamanyo);
		new StyledEditorKit.FontSizeAction("cambiarTamanyo", tamanyo).actionPerformed(e);

	}

	public Font cambiarTipoDeFuente(ActionEvent e, String nombreFuente) {

		Font fuente = new Font(nombreFuente, Font.PLAIN, 16);
		new StyledEditorKit.FontFamilyAction("cambiarFuente", String.valueOf(nombreFuente)).actionPerformed(e);
		this.lamina.cambiarNombreEstilo(nombreFuente);

		System.out.println("Nueva fuente = " + fuente.toString());
		return fuente;

	}

	// Coloreamos el texto
	public void colorearTexto(Color color, ActionEvent e) {

		new StyledEditorKit.ForegroundAction("cambiarColor", color).actionPerformed(e);

	}

	public void negrita(ActionEvent e) {

		
		clickarBoton(this.menu,"Negrita");
		System.out.println("Dentro del evento");
		if (!presNegrita) {
			presNegrita = true;
			//item.setSelected(presNegrita);
		} else
			//presNegrita = false; item.setSelected(presNegrita);
		
		System.out.println("Valor negrita= " + presNegrita);
		
		
		new StyledEditorKit.BoldAction().actionPerformed(e);
		
		

	}

	public void cursiva(ActionEvent e) {

		new StyledEditorKit.ItalicAction().actionPerformed(e);

	}

	public void subrayado(ActionEvent e) {
		new StyledEditorKit.UnderlineAction().actionPerformed(e);
	}

	// Alineamos de forma justificada

	public void alinearJustificado() {
		StyledDocument doc = this.getStyledDocument();
		SimpleAttributeSet centro = new SimpleAttributeSet();
		StyleConstants.setAlignment(centro, StyleConstants.ALIGN_JUSTIFIED);
		doc.setParagraphAttributes(0, doc.getLength(), centro, false);

	}
	// Alineamos el texto al centro

	public void alinearCentro() {

		StyledDocument doc = this.getStyledDocument();
		SimpleAttributeSet centro = new SimpleAttributeSet();
		StyleConstants.setAlignment(centro, StyleConstants.ALIGN_CENTER);
		doc.setParagraphAttributes(0, doc.getLength(), centro, false);

	}

	// alineamos a la derecha
	public void alinearDcha() {
		StyledDocument doc = this.getStyledDocument();
		SimpleAttributeSet dcha = new SimpleAttributeSet();
		StyleConstants.setAlignment(dcha, StyleConstants.ALIGN_RIGHT);
		doc.setParagraphAttributes(0, doc.getLength(), dcha, false);

	}

	// alineamos a la izquierda
	public void alinearIzq() {
		StyledDocument doc = this.getStyledDocument();
		SimpleAttributeSet izq = new SimpleAttributeSet();
		StyleConstants.setAlignment(izq, StyleConstants.ALIGN_LEFT);
		doc.setParagraphAttributes(0, doc.getLength(), izq, false);

	}

	@Override
	public void keyTyped(KeyEvent tecla) {

	}

	@Override
	public void keyPressed(KeyEvent tecla) {
		// ocultarMenu();
		this.lamina.contarPalabras();
		this.lamina.contarCaracteres();
		this.lamina.getVentana().activarUndo();

	}

	@Override
	public void keyReleased(KeyEvent tecla) {

		this.lamina.contarPalabras();
		this.lamina.contarCaracteres();

	}

	public Lamina getLamina() {
		return lamina;
	}

	public void setLamina(Lamina lamina) {
		this.lamina = lamina;
	}

	public JPopupMenu crearMenu() {

		JPopupMenu menu = new JPopupMenu();

		ImageIcon iconoCortar = new ImageIcon("src/iconos/cut.png");
		ImageIcon iconoCopiar = new ImageIcon("src/iconos/copy.png");
		ImageIcon iconoPegar = new ImageIcon("src/iconos/paste.png");
		ImageIcon iconoNegrita = new ImageIcon("src/iconos/negrita.png");
		ImageIcon iconoCursiva = new ImageIcon("src/iconos/cursiva.png");
		ImageIcon iconoSubrayado = new ImageIcon("src/iconos/subrayado.png");
		JMenuItem copiar = new JMenuItem("Copiar");

		copiar.setIcon(this.lamina.getVentana().modificarTamanyo(iconoCopiar));
		copiar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				copy();

			}

		});
		JMenuItem pegar = new JMenuItem("Pegar");

		pegar.setIcon(this.lamina.getVentana().modificarTamanyo(iconoPegar));
		pegar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				paste();

			}

		});
		JMenuItem cortar = new JMenuItem("Cortar");

		cortar.setIcon(this.lamina.getVentana().modificarTamanyo(iconoCortar));
		cortar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				cut();

			}

		});
		JMenuItem bold = new JMenuItem("Negrita");

		System.out.println("Valor negrita= " + presNegrita);
		bold.setIcon(this.lamina.getVentana().modificarTamanyo(iconoNegrita));
		bold.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				lamina.getVentana().btnNegrita.doClick();
				

			}

		});
		JMenuItem italic = new JMenuItem("Cursiva");

		italic.setIcon(this.lamina.getVentana().modificarTamanyo(iconoCursiva));
		italic.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				lamina.getVentana().btnItalic.doClick();

			}
		});

		JMenuItem underline = new JMenuItem("Subrayado");
		underline.setSelected(false);

		underline.setIcon(this.lamina.getVentana().modificarTamanyo(iconoSubrayado));

		underline.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				lamina.getVentana().btnSubrayado.doClick();
				underline.setSelected(true);
				// underline.setIcon(lamina.getVentana().modificarTamanyo(iconoCursiva));

			}

		});

		menu.add("Prueba");
		menu.add(cortar);
		menu.add(copiar);
		menu.add(pegar);

		menu.add(bold);
		menu.add(italic);
		menu.add(underline);
		return menu;
	}
	
	public void clickarBoton(JPopupMenu menu,String nombre) {
		int nros=0;
		System.out.println("Se ha llamado al metodo, el nombre es " +nombre);
		if(nombre.equals("Negrita")) {
			
			
			
			for(int i=0;i<menu.getComponentCount();i++)
				nros++;
			
		}
	System.out.println("Hay "+ nros + " componentes");
		
		
		
		
		
		
	}

	public void mostrarMenu(MouseEvent evento) {

		menu.setLocation(evento.getLocationOnScreen());

	}

	@Override
	public void mouseClicked(MouseEvent evento) {
		int click = evento.getButton();
		if (click == MouseEvent.BUTTON1) {
			// ocultarMenu();
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	public JPopupMenu getMenu() {
		return menu;
	}

	public void setMenu(JPopupMenu menu) {
		this.menu = menu;
	}

	@Override
	public void mousePressed(MouseEvent evento) {

	}

	@Override
	public void mouseReleased(MouseEvent evento) {

		// System.out.println("Click");
		int click = evento.getButton();
		if (click == MouseEvent.BUTTON3) {

			mostrarMenu(evento);

		}

	}

}
