/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.awt.BorderLayout;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author amfro
 */
public class Lamina extends JPanel {

	private Pagina pagina;
	private Ventana ventana;
	// Para contar el numero de letras

	private JTextField campoPalabras, campoPagina, campoCaracteres, idioma, campoEstilo;
	private int nroPalabras, nroCaracteres;
	private int nroPagina;
	// Nos permitirá saber la página en la que estamos.

	// el label que nos dirá "numero de letras"
	private JLabel labelPalabras, labelPagina, labelCaracteres;
	private String estiloPagina;

	public Lamina(Ventana ventana) {

		this.ventana = ventana;
		this.setLayout(new BorderLayout());
		this.nroPagina = this.ventana.getLaminas().size() + 1;
		this.estiloPagina = ventana.estilo;
		this.componentes();

		this.setVisible(true);

	}

	// Establecemos los componentes inciales del panel
	public void componentes() {

		pagina = new Pagina(this);

		this.add(pagina);
		JPanel informacionPagina = new JPanel();
		// Iniciamos el nro de pagina,palabras, y los label, lo introducimos en un panel
		// y lo posicionamos

		this.nroPalabras = 0;
		this.nroCaracteres = 0;
		this.campoPalabras = new JTextField(nroPalabras + "    ");
		campoPalabras.setEditable(false);
		this.labelPalabras = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_palabras"));
		this.labelPagina = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_pagina"));
		this.campoPagina = new JTextField(nroPagina + "");
		campoPagina.setEditable(false);
		this.campoEstilo = new JTextField(estiloPagina + "");

		this.campoEstilo.setEditable(false);

		this.campoCaracteres = new JTextField(nroCaracteres + "");
		this.labelCaracteres = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_caracteres"));
		this.campoCaracteres.setEditable(false);
		JLabel labelEstilo = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_estilo"));

		JLabel labelIdioma = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_idioma"));
		idioma = new JTextField();
		idioma.setText(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_idiomaGeneral") + " ");
		idioma.setEditable(false);

		informacionPagina.add(labelIdioma, BorderLayout.WEST);
		informacionPagina.add(idioma, BorderLayout.WEST);
		informacionPagina.add(labelPalabras, BorderLayout.WEST);
		informacionPagina.add(campoPalabras, BorderLayout.WEST);

		informacionPagina.add(labelCaracteres, BorderLayout.CENTER);
		informacionPagina.add(campoCaracteres, BorderLayout.CENTER);

		informacionPagina.add(labelPagina, BorderLayout.EAST);
		informacionPagina.add(campoPagina, BorderLayout.EAST);

		informacionPagina.add(labelEstilo, BorderLayout.EAST);
		informacionPagina.add(campoEstilo, BorderLayout.EAST);

		informacionPagina.setVisible(true);
		add(informacionPagina, BorderLayout.SOUTH);
	}

	public void contarCaracteres() {

		this.nroCaracteres = this.getPagina().getText().length();
		this.campoCaracteres.setText(nroCaracteres + "");

	}

	// Usar un m�todo similar para las palabras

	public void contarPalabras() {

		if (this.nroCaracteres == 0)
			nroPalabras = 0;
		else {
			String texto = this.getPagina().getText();

			nroPalabras = texto.split("\\s+|\n|,").length;

			this.campoPalabras.setText(nroPalabras + "");
		}

	}

	public void cambiarNombreEstilo(String nombreEstilo) {
		this.campoEstilo.setText(nombreEstilo);
	}

	public void incrementarNroPaginas() {

		int nro = this.nroPagina = this.ventana.getLaminas().size();
		this.campoPagina.setText(" " + nro + "  ");

	}

	public Pagina getPagina() {
		return pagina;
	}

	public void setPagina(Pagina pagina) {
		this.pagina = pagina;
	}

	public Ventana getVentana() {
		return ventana;
	}

	public JTextField getCampoPalabras() {
		return campoPalabras;
	}

	public JTextField getCampoLetras() {
		return campoPalabras;
	}

	public void setCampoLetras(JTextField campoLetras) {
		this.campoPalabras = campoLetras;
	}

	public JTextField getCampoPagina() {
		return campoPagina;
	}

	public void setCampoPagina(JTextField campoPagina) {
		this.campoPagina = campoPagina;
	}

	public int getNroPalabras() {
		return nroPalabras;
	}

	public void setNroPalabras(int nroPalabras) {
		this.nroPalabras = nroPalabras;
	}

	public int getNroPagina() {
		return nroPagina;
	}

	public void setNroPagina(int nroPagina) {
		this.nroPagina = nroPagina;
	}

	public JLabel getLabelPalabras() {
		return labelPalabras;
	}

	public void setLabelPalabras(JLabel labelPalabras) {
		this.labelPalabras = labelPalabras;
	}

	public JLabel getLabelPagina() {
		return labelPagina;
	}

	public void setLabelPagina(JLabel labelPagina) {
		this.labelPagina = labelPagina;
	}

}
