/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import javax.swing.undo.UndoManager;

/**
 *
 * @author amfro
 */
public class Ventana extends JFrame implements ActionListener, KeyListener, WindowListener {
	ArrayList<Lamina> laminas;
	Lamina primeraLamina;
	boolean guardado = false;
	private UndoManager undoManager;
	private boolean primeraVez = true;
	File currentFile;
	JFrame jFrame;

	JToggleButton btnNegrita, btnItalic, btnSubrayado;
	JButton btnCortar, btnCopiar, btnPegar, btnAyuda, btnInformacion;
	JButton btnUndo, btnRedo;

	// para controlar los botones pulsados

	public String estilo;

	public Ventana() {

		// Titulo
		setTitle("Nuevo archivo");
		this.jFrame = this;
		// Tamaño y posicion
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Dimension tamanyoPantalla = mipantalla.getScreenSize();
		this.setSize(tamanyoPantalla.width - 100, tamanyoPantalla.height - 100);
		this.undoManager = new UndoManager();
		undoManager.setLimit(15);

		ImageIcon iconoEditor = new ImageIcon("src/iconos/iconoPrincipal.png");
		Image imagenIcono = iconoEditor.getImage();
		this.setIconImage(imagenIcono);

		this.centrarVentana();
		componentes();
		this.setVisible(true);

		addKeyListener(this);
		addWindowListener(this);

	}

	public void centrarVentana() {
		setLocationRelativeTo(null);
	}

	public void componentes() {

		this.laminas = new ArrayList<Lamina>();
		this.primeraLamina = new Lamina(this);
		primeraLamina.setVisible(true);
		primeraLamina.setSize(this.getHeight() - 100, this.getWidth() - 100);
		laminas.add(primeraLamina);
		add(primeraLamina);
		anyadirMenu();
		anyadirBarraHerramientas();

	}

	public void anyadirLamina() {
		Lamina lamina = new Lamina(this);
		laminas.add(lamina);
		//
		add(lamina);

	}

	public void cambiarTitulo(String nuevoTitulo) {
		this.setTitle(nuevoTitulo);
	}

	// AQUI CREAMOS LA BARRA DE MENU CON SUS COMPONENTES

	public void anyadirMenu() {
		JMenuBar barraMenu = new JMenuBar();
		JMenu archivo = new JMenu();
		archivo.setMnemonic(KeyEvent.VK_A);
		archivo.setText(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_archivo"));
		JMenu editar = new JMenu(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_editar"));
		editar.setMnemonic(KeyEvent.VK_E);
		// InputEvent.CTRL_DOWN_MASK));
		JMenu ayuda = new JMenu(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_ayuda"));
		ayuda.setMnemonic(KeyEvent.VK_U);
		barraMenu.add(archivo);
		barraMenu.add(editar);
		barraMenu.add(ayuda);
		JMenuItem nuevo = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_nuevo"));
		nuevo.setIcon(new ImageIcon("src/iconos/nuevo.png"));
		nuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
		JMenuItem abrir = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_abrir"));
		abrir.setIcon(new ImageIcon("src/iconos/abrir.png"));
		abrir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
		JMenuItem guardar = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_guardar"));
		guardar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK));
		ImageIcon guardado = new ImageIcon("src/iconos/guardado.png");
		JMenuItem guardarComo = new JMenuItem(
				ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_guardarComo"));
		guardarComo.setIcon(guardado);
		guardar.setIcon(guardado);
		guardarComo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK));
		JMenuItem imprimir = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_imprimir"));
		imprimir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK));
		imprimir.setIcon(new ImageIcon("src/iconos/imprimir.png"));
		JMenuItem salir = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_salir"));
		salir.setIcon(new ImageIcon("src/iconos/exit.png"));
		salir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));

		abrir.setVisible(true);
		guardar.setVisible(true);
		salir.setVisible(true);
		archivo.add(nuevo);
		archivo.add(guardar);
		archivo.add(guardarComo);
		archivo.add(abrir);
		archivo.addSeparator();
		archivo.add(imprimir);
		archivo.add(salir);
		// Incorporamos funcionalidades al menu
		nuevo.addActionListener(this);
		abrir.addActionListener(this);
		guardar.addActionListener(this);
		guardarComo.addActionListener(this);
		imprimir.addActionListener(this);
		salir.addActionListener(this);

		JMenuItem pegar = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_pegar"));
		JMenuItem copiar = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_copiar"));
		JMenuItem cortar = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_cortar"));

		ImageIcon iconoCortar = new ImageIcon("src/iconos/cut.png");
		ImageIcon iconoCopiar = new ImageIcon("src/iconos/copy.png");
		ImageIcon iconoPegar = new ImageIcon("src/iconos/paste.png");

		pegar.setIcon(iconoPegar);
		cortar.setIcon(iconoCortar);
		copiar.setIcon(iconoCopiar);

		editar.add(cortar);
		editar.add(copiar);
		editar.add(pegar);
		// Incorporamos las funciones del editor
		pegar.addActionListener(this);
		cortar.addActionListener(this);
		copiar.addActionListener(this);

		ImageIcon iconoAyuda = new ImageIcon("src/iconos/help.png");
		ImageIcon iconoInformacion = new ImageIcon("src/iconos/information.png");

		JMenuItem informacion = new JMenuItem(
				ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_informacion"));
		informacion.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK));
		JMenuItem acercaDe = new JMenuItem(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_acercaDe"));
		informacion.setVisible(true);
		informacion.setIcon(iconoInformacion);
		acercaDe.setVisible(true);
		acercaDe.setIcon(iconoAyuda);
		ayuda.add(informacion);
		ayuda.add(acercaDe);
		acercaDe.addActionListener(this);
		informacion.addActionListener(this);

		archivo.setVisible(true);
		editar.setVisible(true);
		ayuda.setVisible(true);
		barraMenu.setVisible(true);
		setJMenuBar(barraMenu);

	}

	// INCORPORAMOS LA BARRA DE HERRAMIENTAS

	public void anyadirBarraHerramientas() {

		Lamina lamina = primeraLamina;
		JToolBar barraHerramientas = new JToolBar();

		// Incorporamos menus rapidos

		JButton btnAbrir, btnGuardado, btnInsertarImagen, btnNuevo, btnImprimir, btnPaletaColor;

		btnNuevo = new JButton();
		ImageIcon iconoNuevo = new ImageIcon("src/iconos/nuevo.png");
		btnNuevo.setIcon(modificarTamanyo(iconoNuevo));
		btnNuevo.setToolTipText("Crear un nuevo archivo");

		btnAbrir = new JButton();
		ImageIcon iconoAbrir = new ImageIcon("src/iconos/abrir.png");
		btnAbrir.setIcon(modificarTamanyo(iconoAbrir));
		btnAbrir.setToolTipText("Abrir un archivo");

		btnGuardado = new JButton();
		ImageIcon iconoGuardar = new ImageIcon("src/iconos/guardado.png");
		btnGuardado.setIcon(modificarTamanyo(iconoGuardar));
		btnGuardado.setToolTipText("Guardar como");

		btnInsertarImagen = new JButton();
		ImageIcon iconoImagen = new ImageIcon("src/iconos/insertarImagen.png");
		btnInsertarImagen.setIcon(modificarTamanyo(iconoImagen));
		btnInsertarImagen.setToolTipText("Insertar una imagen");

		btnImprimir = new JButton();
		ImageIcon iconoImprimir = new ImageIcon("src/iconos/imprimir.png");
		btnImprimir.setIcon(modificarTamanyo(iconoImprimir));
		btnImprimir.setToolTipText("Imprimir");

		btnImprimir.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				imprimir();

			}

		});

		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nuevo();

			}

		});

		btnAbrir.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				abrir();

			}

		});

		btnGuardado.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				System.out.println(primeraVez);
				if (primeraVez) {
					guardarComo();
					primeraVez = false;
					System.out.println(primeraVez);
				} else
					guardar();

			}

		});

		btnInsertarImagen.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				insertarImagen();

			}

		});
		JLabel estilo = new JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_estilo"));
		estilo.setFont(new Font("", Font.PLAIN, 16));

		// Incorporamos los botones al menu

		barraHerramientas.add(btnNuevo);
		barraHerramientas.add(btnGuardado);
		barraHerramientas.add(btnAbrir);
		barraHerramientas.add(btnImprimir);
		barraHerramientas.addSeparator();
		barraHerramientas.add(estilo);
		barraHerramientas.addSeparator();

		// Incorporamos los botones de negrita, subrayado e italica

		ImageIcon iconoCortar = new ImageIcon("src/iconos/cut.png");
		ImageIcon iconoCopiar = new ImageIcon("src/iconos/copy.png");
		ImageIcon iconoPegar = new ImageIcon("src/iconos/paste.png");
		ImageIcon iconoAyuda = new ImageIcon("src/iconos/help.png");
		ImageIcon iconoInformacion = new ImageIcon("src/iconos/information.png");

		btnCortar = new JButton();
		btnCortar.setIcon(modificarTamanyo(iconoCortar));
		btnCortar.setToolTipText("Cortar");
		btnCopiar = new JButton();
		btnCopiar.setIcon(modificarTamanyo(iconoCopiar));
		btnCopiar.setToolTipText("Copiar");
		btnPegar = new JButton();
		btnPegar.setIcon(modificarTamanyo(iconoPegar));
		btnPegar.setToolTipText("Pegar");
		btnAyuda = new JButton();
		btnAyuda.setIcon(modificarTamanyo(iconoAyuda));
		btnAyuda.setToolTipText("Ayuda");
		btnInformacion = new JButton();
		btnInformacion.setIcon(modificarTamanyo(iconoInformacion));
		btnInformacion.setToolTipText("Informaci�n");

		btnNegrita = new JToggleButton();

		ImageIcon iconoNegrita = new ImageIcon("src/iconos/negrita.png");
		btnNegrita.setIcon(modificarTamanyo(iconoNegrita));
		btnNegrita.setMnemonic(KeyEvent.VK_B);
		btnNegrita.setToolTipText("Negrita");

		btnItalic = new JToggleButton();
		ImageIcon iconoCursiva = new ImageIcon("src/iconos/cursiva.png");
		btnItalic.setIcon(modificarTamanyo(iconoCursiva));
		btnItalic.setMnemonic(KeyEvent.VK_C);
		btnItalic.setToolTipText("Cursiva");

		btnSubrayado = new JToggleButton();
		ImageIcon iconoSubrayado = new ImageIcon("src/iconos/subrayado.png");
		btnSubrayado.setIcon(modificarTamanyo(iconoSubrayado));
		btnSubrayado.setMnemonic(KeyEvent.VK_S);
		btnSubrayado.setToolTipText("Subrayado");
		btnPaletaColor = new JButton();
		ImageIcon iconoPaleta = new ImageIcon("src/iconos/iconoPaleta.png");
		btnPaletaColor.setIcon(modificarTamanyo(iconoPaleta));
		btnPaletaColor.setMnemonic(KeyEvent.VK_P);
		btnPaletaColor.setToolTipText("Paleta de colores");

		JPanel panelColor = new JPanel();
		panelColor.setSize(20, 30);
		panelColor.setToolTipText("Color actual");
		// panelColor.setMinimumSize(new Dimension(500, 60));
		// panelColor.setMaximumSize(new Dimension(500, 60));
		panelColor.setBackground(Color.BLACK);
		// this.primeraLamina.getPagina().getCaretColor());

		barraHerramientas.add(btnCortar);
		barraHerramientas.add(btnCopiar);
		barraHerramientas.add(btnPegar);
		barraHerramientas.addSeparator();
		barraHerramientas.add(btnNegrita);
		barraHerramientas.add(btnNegrita);
		barraHerramientas.add(btnItalic);
		barraHerramientas.add(btnSubrayado);
		barraHerramientas.add(btnPaletaColor);
		barraHerramientas.add(panelColor);

		barraHerramientas.addSeparator();
		barraHerramientas.addSeparator();
		barraHerramientas.add(btnInsertarImagen);

		barraHerramientas.addSeparator();
		barraHerramientas.setVisible(true);

		add(barraHerramientas, BorderLayout.NORTH);

		// Tama�os de letras
		JComboBox<Integer> tamanyoLetra = new JComboBox<Integer>();
		// tamanyoLetra.setMinimumSize(new Dimension(50, 25));
		// tamanyoLetra.setMaximumSize(new Dimension(50, 25));
		tamanyoLetra.setToolTipText("Tama�o de la fuente");

		for (int i = 20; i < 80; i = i + 2) {
			tamanyoLetra.addItem(i);

		}

		tamanyoLetra.setSelectedIndex(2);
		// tamanyoLetra.addActionListener(this);
		tamanyoLetra.setVisible(true);
		// JLabel labelTamanyoLetra = new
		// JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_tamanyo"));
		// labelTamanyoLetra.setFont(new Font("", Font.PLAIN, 16));

		// Fuentes
		// JLabel labelFuente = new
		// JLabel(ResourceBundle.getBundle("idiomas.lengua").getString("etiqueta_fuente"));
		// labelFuente.setFont(new Font("", Font.PLAIN, 16));
		// labelFuente

		JComboBox<String> fuentes = new JComboBox<String>();
		fuentes.setToolTipText("Tipo de fuente");

		// fuentes.setMinimumSize(new Dimension(140, 25));
		// fuentes.setMaximumSize(new Dimension(190, 25));

		GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
		String[] misFuentes = e.getAvailableFontFamilyNames();

		for (String fuente : misFuentes) {

			fuentes.addItem(fuente);

		}
		fuentes.setSelectedIndex(0);

		this.estilo = fuentes.getSelectedItem().toString();

		tamanyoLetra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int tamanyo = Integer.parseInt(tamanyoLetra.getSelectedItem().toString());

				primeraLamina.getPagina().cambiarTamanyoTexto(e, tamanyo);

			}

		});

		// de las fuentes

		fuentes.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String nombreFuente = fuentes.getSelectedItem().toString();
				Font font = primeraLamina.getPagina().cambiarTipoDeFuente(e, nombreFuente);
				System.out.println("Nueva fuente = " + font.toString());
				// estilo.setFont(font);
				// labelFuente.setFont(font);
				// labelTamanyoLetra.setFont(font);

			}

		});

		btnAyuda.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				ayuda();

			}
		});

		btnInformacion.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				acercaDe();
			}

		});

		btnCopiar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().copy();

			}

		});

		btnPegar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().paste();

			}

		});

		btnCortar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().cut();

			}

		});
		/*
		 * btnSubrayadoColor.addActionListener(new ActionListener() {
		 * 
		 * public void actionPerformed(ActionEvent e) {
		 * 
		 * Color color = cogerColor(); primeraLamina.getPagina().subrayarColor(color,
		 * e); panelColor.setBackground(color);
		 * 
		 * }
		 * 
		 * });
		 */
		btnPaletaColor.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// Abre la paleta
				Color color = cogerColor();
				primeraLamina.getPagina().colorearTexto(color, e);

				panelColor.setBackground(color);

			}

		});
		btnNegrita.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().negrita(e);

			}

		});

		btnItalic.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().cursiva(e);

			}

		});
		btnSubrayado.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				primeraLamina.getPagina().subrayado(e);
				// primeraLamina.getPagina().getMenu().

			}

		});

		barraHerramientas.addSeparator();
		// barraHerramientas.add(labelFuente);
		barraHerramientas.add(fuentes);
		barraHerramientas.addSeparator();
		// barraHerramientas.add(labelTamanyoLetra);
		barraHerramientas.add(tamanyoLetra);
		barraHerramientas.addSeparator();

		// Pasamos las propiedades a la p�gina por defecto

		this.preparaPagina(fuentes.getSelectedItem().toString(),
				Integer.parseInt(tamanyoLetra.getSelectedItem().toString()));

		barraHerramientas.setVisible(true);
		// Hacer y deshacer

		btnUndo = new JButton();
		ImageIcon iconoUndo = new ImageIcon("src/iconos/undo.png");
		btnUndo.setIcon(modificarTamanyo(iconoUndo));
		btnUndo.setEnabled(false);
		btnUndo.setToolTipText("Deshacer");

		btnRedo = new JButton();
		ImageIcon iconoRedo = new ImageIcon("src/iconos/redo.png");
		btnRedo.setIcon(modificarTamanyo(iconoRedo));
		btnRedo.setEnabled(false);
		btnRedo.setToolTipText("Rehacer");

		// Funcionalidad de los botones

		// Incorporo los botones
		barraHerramientas.add(btnUndo);
		barraHerramientas.add(btnRedo);

		btnUndo.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				deshacer();
				activarRedo();

			}

		});

		btnRedo.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				rehacer();
			}

		});

		// Alineacion

		JButton btnJustificado = new JButton();
		ImageIcon iconoJustificado = new ImageIcon("src/iconos/textoNormal.png");
		btnJustificado.setIcon(modificarTamanyo(iconoJustificado));
		btnJustificado.setToolTipText("Texto justificado");

		JButton btnCentrar = new JButton();
		ImageIcon iconoCentrar = new ImageIcon("src/iconos/textoCentrado.png");

		btnCentrar.setIcon(modificarTamanyo(iconoCentrar));
		btnCentrar.setToolTipText("Centrar");

		JButton btnIzq = new JButton();
		ImageIcon iconoIzq = new ImageIcon("src/iconos/textoIzqda.png");
		btnIzq.setIcon(modificarTamanyo(iconoIzq));
		btnIzq.setToolTipText("Texto alineado a la izquierda");
		JButton btnDcha = new JButton();
		ImageIcon iconoDcha = new ImageIcon("src/iconos/textoDcha.png");
		btnDcha.setIcon(modificarTamanyo(iconoDcha));
		btnDcha.setToolTipText("Texto alineado a la derecha");

		// Incorporamos los botones de alineacion
		btnJustificado.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				lamina.getPagina().alinearJustificado();

			}

		});

		btnCentrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lamina.getPagina().alinearCentro();

			}

		});
		btnIzq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lamina.getPagina().alinearIzq();

			}

		});
		btnDcha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lamina.getPagina().alinearDcha();

			}

		});
		barraHerramientas.add(btnJustificado);
		barraHerramientas.add(btnCentrar);
		barraHerramientas.add(btnIzq);
		barraHerramientas.add(btnDcha);
		barraHerramientas.addSeparator();
		barraHerramientas.add(btnAyuda);
		barraHerramientas.add(btnInformacion);

		JComboBox<String> skin = new JComboBox<String>();
		UIManager.LookAndFeelInfo[] lafinfo = UIManager.getInstalledLookAndFeels();
		for (int i = 0; i < lafinfo.length; i++) {
			skin.addItem(lafinfo[i].getName());
			// System.out.println(lafinfo[i].getClassName());
		}

		skin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				try {

					int seleccion = skin.getSelectedIndex();

					UIManager.setLookAndFeel(lafinfo[seleccion].getClassName());
					SwingUtilities.updateComponentTreeUI(jFrame);

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}

		});

		skin.setMinimumSize(new Dimension(100, 25));
		skin.setMaximumSize(new Dimension(190, 25));
		skin.setToolTipText("Apariencia");
		barraHerramientas.addSeparator();
		barraHerramientas.add(skin);

	}

	// Para dar las funcionalidades del menu
	public void actionPerformed(ActionEvent evento) {
		guardado = false;

		String nombreEvento = evento.getActionCommand();

		if (nombreEvento.equals("Abrir")) {
			abrir();

		} else if (nombreEvento.equals("Nuevo")) {
			nuevo();

		} else if (nombreEvento.equals("Guardar como")) {
			guardarComo();
			guardado = true;
		}

		else if (nombreEvento.equals("Guardar")) {

			guardar();
			guardado = true;
		}

		else if (nombreEvento.equals("Salir")) {

			salir();

		} else if (nombreEvento.contentEquals("Imprimir")) {
			imprimir();
		} else if (nombreEvento.equals("Pegar")) {
			this.primeraLamina.getPagina().paste();
		} else if (nombreEvento.equals("Copiar")) {
			this.primeraLamina.getPagina().copy();

		} else if (nombreEvento.equals("Cortar")) {
			this.primeraLamina.getPagina().cut();
		} else if (nombreEvento.equals("Informaci�n")) {
			ayuda();

		} else if (nombreEvento.equals("Acerca de")) {
			acercaDe();

		}

	}

	public void activarUndo() {

		this.btnUndo.setEnabled(true);

	}

	public void activarRedo() {

		this.btnRedo.setEnabled(true);
	}

	public void ayuda() {

		JOptionPane.showMessageDialog(this,
				"Accesos r�pidos:\n" + "CNTRL+O: Abrir \n" + "CNTRL+N: Nuevo \n" + "CNTRL+G: Guardar \n"
						+ "CNTRL+I: Imprimir \n" + "CNTRL+Y: Ayuda \n" + "CNTRL+P: Pegar \n" + "CNTRL+X: Cortar \n"
						+ "CNTRL+C: Copiar \n" + "ALT+B: Negrita \n" + "ALT+C: Cursiva \n" + "ALT+S: Subrayado \n"
						+ "ALT+P: Paleta color");

	}

	public void acercaDe() {

		JOptionPane.showMessageDialog(this, "Desarrollado por Adri�n Mar�n Palaz�n 2�DAM");

	}

	public Color cogerColor() {

		return JColorChooser.showDialog(null, "Color", Color.RED);

	}

	public void salir() {
		if (!guardado) {
			int respuesta = JOptionPane.showConfirmDialog(null, "�Salir sin guardar?");
			if (JOptionPane.OK_OPTION == respuesta)
				dispose();
		} else {
			int respuesta = JOptionPane.showConfirmDialog(null, "�Salir?");
			if (JOptionPane.OK_OPTION == respuesta)
				dispose();
		}
	}

	public void guardar() {

		if (currentFile != null) {
			try {
				FileWriter fw = new FileWriter(currentFile);
				// String text = view.textPane.getText().replaceAll("\r", "<br/>");
				String text = this.primeraLamina.getPagina().getText();
				fw.write(text);
				fw.close();
			} catch (FileNotFoundException fnfe) {
				System.err.println("FileNotFoundException: " + fnfe.getMessage());
			} catch (IOException ioe) {
				System.err.println("IOException: " + ioe.getMessage());
			}
		} else {
			guardarComo();
		}
		guardado = true;
	}

	public void guardarComo() {

		try {
			File current = new File(".");
			JFileChooser chooser = new JFileChooser(current);
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			chooser.setAcceptAllFileFilterUsed(false);

			int response = chooser.showSaveDialog(this);

			if (response == JFileChooser.APPROVE_OPTION) {

				FileFilter fileFilter = chooser.getFileFilter();

				File newFile = chooser.getSelectedFile();
				if (newFile.exists()) {
					String message = newFile.getAbsolutePath() + " ya existe. \n " + "�Quieres reemplazarlo?";
					if (JOptionPane.showConfirmDialog(this, message) == JOptionPane.YES_OPTION) {
						currentFile = newFile;
						this.setTitle(currentFile.getName());
						FileWriter fw = new FileWriter(currentFile);
						// String text = view.textPane.getText().replaceAll("\r", "<br/>");
						String text = this.primeraLamina.getPagina().getText();
						fw.write(text);
						fw.close();
					}
				} else {
					currentFile = new File(newFile.getAbsolutePath() + ".txt");
					this.setTitle(currentFile.getName());
					FileWriter fw = new FileWriter(currentFile);
					fw.write(this.primeraLamina.getPagina().getText());
					fw.close();
					guardado = true;
				}
			}
		} catch (FileNotFoundException fnfe) {
			System.err.println("FileNotFoundException: " + fnfe.getMessage());
			guardado = false;
		} catch (IOException ioe) {
			System.err.println("IOException: " + ioe.getMessage());
			guardado = false;
		}
	}

	// Metodos para nuevo etc...

	public void nuevo() {

		int respuesta = JOptionPane.showConfirmDialog(null, "�Crear un nuevo archivo?");
		if (JOptionPane.OK_OPTION == respuesta) {

			this.dispose();

			new Ventana();

		}

	}

	public void deshacer() {

		try {
			if (this.getUndoManager().canUndo())
				this.getUndoManager().undo();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void rehacer() {

		try {
			if (this.getUndoManager().canRedo())
				this.getUndoManager().redo();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void abrir() {

		int respuesta = JOptionPane.showConfirmDialog(null, "�Abrir un nuevo archivo?");

		if (JOptionPane.OK_OPTION == respuesta) {

			this.primeraLamina.getPagina().setText("");

			JFileChooser j = new JFileChooser("d:/usuarios/DAM/Desktop");
			FileNameExtensionFilter filtro = new FileNameExtensionFilter(".TXT", "txt");
			j.setFileFilter(filtro);
			int nro = j.showOpenDialog(null);

			if (nro == JFileChooser.APPROVE_OPTION) {

				File fi = new File(j.getSelectedFile().getAbsolutePath());
				String nuevoTitulo = j.getName(fi);

				this.setTitle(nuevoTitulo);
				try {
					// String
					String texto = "", linea = "";

					// File reader
					FileReader fr = new FileReader(fi);

					// Buffered reader
					BufferedReader br = new BufferedReader(fr);

					// Inicializamos linea
					linea = br.readLine();

					while ((texto = br.readLine()) != null) {
						linea = linea + "\n" + texto;
					}

					// Seleccionamos el texto
					this.primeraLamina.getPagina().setText(linea);
					this.preparaPagina(this.primeraLamina.getPagina().getFont().getName(),
							this.primeraLamina.getPagina().getFont().getSize());
					currentFile = new File(fi.getAbsolutePath());

				} catch (Exception evt) {
					JOptionPane.showMessageDialog(this, evt.getMessage());
				}
			}
			// Si se cancela
		} else
			JOptionPane.showMessageDialog(this, "La operaci�n ha sido cancelada");

	}

	/*
	 * public String titulo(String nombre) { int i = 0; boolean seguir = true;
	 * String retorno = ""; while (seguir) { System.out.println("valor de i= " + i);
	 * if (i >= nombre.length()) { seguir = false; return retorno; } else if
	 * (nombre.charAt(i) == '.') { seguir = false; return retorno; } retorno =
	 * retorno + nombre.charAt(i); System.out.println("El caracter es +" +
	 * nombre.charAt(i)); i++; } System.out.println("El valor final es =" +
	 * retorno); return retorno; }
	 */

	private void insertarImagen() {

		JFileChooser j = new JFileChooser("c:");
		FileNameExtensionFilter png = new FileNameExtensionFilter("PNG (*.png)", "png");
		j.setFileFilter(png);
		FileNameExtensionFilter jpg = new FileNameExtensionFilter("JPEG (*.jpg)", "jpg");
		j.setFileFilter(jpg);
		int nro = j.showOpenDialog(null);

		if (nro == JFileChooser.APPROVE_OPTION) {

			String ruta = j.getSelectedFile().getAbsolutePath();

			ImageIcon foto = new ImageIcon(ruta);
			int position = this.primeraLamina.getPagina().getStyledDocument().getLength();
			this.primeraLamina.getPagina().setCaretPosition(position);
			this.primeraLamina.getPagina().insertIcon(foto);

		}

	}

	public void imprimir() {

		try {
			boolean done = this.primeraLamina.getPagina().print();
			if (done) {
				JOptionPane.showMessageDialog(null, "Impresi�n correcta");
			} else {
				JOptionPane.showMessageDialog(null, "Hubo un error al imprimir");
			}
		} catch (PrinterException | HeadlessException pex) {
			JOptionPane.showMessageDialog(null, "Hubo un error al imprimir");
		}

	}

	public void preparaPagina(String nombreFuente, int tamanyo) {
		this.primeraLamina.getPagina().iniciar(nombreFuente, tamanyo);
		this.primeraLamina.contarCaracteres();
		this.primeraLamina.contarPalabras();
		this.primeraLamina.cambiarNombreEstilo(nombreFuente);

	}

	public ImageIcon modificarTamanyo(ImageIcon icono) {

		Image img = icono.getImage();
		ImageIcon nuevoIcono = new ImageIcon(img.getScaledInstance(30, 30, Image.SCALE_SMOOTH));

		return nuevoIcono;

	}

	public void keyTyped(KeyEvent e) {
		guardado = false;
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public void keyPressed(KeyEvent e) {
		guardado = false;
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public void keyReleased(KeyEvent e) {
		guardado = false;
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	public ArrayList<Lamina> getLaminas() {
		return laminas;
	}

	public void setLaminas(ArrayList<Lamina> laminas) {
		this.laminas = laminas;
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {

	}

	@Override
	public void windowClosing(WindowEvent arg0) {

		this.salir();

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	public UndoManager getUndoManager() {
		return undoManager;
	}

	public void setUndoManager(UndoManager undoManager) {
		this.undoManager = undoManager;
	}

	class ItemRenderer extends BasicComboBoxRenderer {
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

			Item item = (Item) value;

			if (index == -1) {
				setText(item.getText());
				setIcon(null);
			} else {
				setText(item.getText());
				setIcon(item.getIcon());
			}
			return this;
		}
	}

	class Item {
		private Icon icon;
		private String text;

		public Item(Icon icon, String text) {
			this.icon = icon;
			this.text = text;
		}

		public Icon getIcon() {
			return icon;
		}

		public String getText() {
			return text;
		}
	}

}
